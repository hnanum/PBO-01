/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KasirTokoSepatu;

/**
 *
 * @author Hanafitria Anjani
 */
public class Customer {
    String idCustomer;
    String namaLengkap;
    String alamat;
    String noTelepon;

    Customer(String idCustomer, String namaLengkap, String alamat, String noTelepon) {
        this.idCustomer = idCustomer;
        this.namaLengkap = namaLengkap;
        this.alamat = alamat;
        this.noTelepon = noTelepon;
    }
}
