/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KasirTokoSepatu;

/**
 *
 * @author Hanafitria Anjani
 */
public class Produk {
    String idProduk;
    String namaProduk;
    double hargaSatuan;
    String kategori;
    int stok;

    Produk(String idProduk, String namaProduk, double hargaSatuan, String kategori, int stok) {
        this.idProduk = idProduk;
        this.namaProduk = namaProduk;
        this.hargaSatuan = hargaSatuan;
        this.kategori = kategori;
        this.stok = stok;
    }
    void updateStok(int jumlah){
        this.stok -= jumlah;
    }
}
