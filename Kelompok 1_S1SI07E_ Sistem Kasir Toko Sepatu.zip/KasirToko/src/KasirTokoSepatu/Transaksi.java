/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KasirTokoSepatu;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Hanafitria Anjani
 */
public class Transaksi {
     String idTransaksi;
    Date tglTransaksi;
    double totalHarga;
    String metodeBayar;
    String statusBayar;
    Customer customer;
    List<Produk> produkList = new ArrayList<>();


    Transaksi(String idTransaksi, Customer customer) {
        this.idTransaksi = idTransaksi;
        this.tglTransaksi = new Date();
        this.customer = customer;
    }
    
    void tambahProduk(Produk produk, int jumlah) throws Exception {
        if (produk.stok < jumlah){
            throw new Exception("Stok tidak mencukupi");
        }
        produk.updateStok(jumlah);
        for (int i = 0; i < jumlah; i++) {
            this.produkList.add(produk);
        }
        this.totalHarga += produk.hargaSatuan * jumlah;
    }

    void bayar(double uangBayar) throws Exception {
        if (uangBayar < totalHarga){
            throw new Exception("Uang Bayar Kurang");
        }
        this.statusBayar = "Lunas";

    }

}
