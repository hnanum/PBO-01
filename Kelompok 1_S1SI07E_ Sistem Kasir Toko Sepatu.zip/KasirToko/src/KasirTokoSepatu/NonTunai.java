/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KasirTokoSepatu;

/**
 *
 * @author Hanafitria Anjani
 */
public class NonTunai extends Transaksi {
    String namaPlatform;
    String noReferensi;

    NonTunai(String idTransaksi, Customer customer) {
        super(idTransaksi, customer);
        this.metodeBayar = "Non-Tunai";
    }

    boolean verifikasiPembayaran() {
        // Simulate verification process
        return true; // Replace with actual verification logic
    }
    
}
