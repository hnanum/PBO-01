/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package KasirTokoSepatu;

import java.util.Scanner;

/**
 *
 * @author Hanafitria Anjani
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Contoh penggunaan
        Owner owner = new Owner("owner", "password", "John Doe");
        Karyawan karyawan = new Karyawan("karyawan", "password", "Jane Doe", "08123456789");
        Sepatu sepatu1 = new Sepatu("SP001", "Sepatu Olahraga", 200000, "Sepatu", 10, "Olahraga", "40");
        Sandal sandal1 = new Sandal("SD001", "Sandal Jepit", 50000, "Sandal", 20, "Jepit", "karet", "40");

        System.out.println("Selamat datang di Kasir Toko Sepatu!");

        //Login
        System.out.println("Masukkan username:");
        String username = scanner.nextLine();
        System.out.println("Masukkan password:");
        String password = scanner.nextLine();

        boolean loginSukses = false;
        if (owner.login(username, password)){
            loginSukses = true;
        }else if (karyawan.login(username, password)){
            loginSukses = true;
        }

        if (loginSukses){
            System.out.println("Login Sukses!");

            //Transaksi
            System.out.println("Buat transaksi baru? (y/n)");
            String jawab = scanner.nextLine();

            if (jawab.equalsIgnoreCase("y")){
                System.out.println("Masukkan ID Customer:");
                String idCustomer = scanner.nextLine();
                Customer customer; //ganti sesuai tipe customer
                customer = new NonMember(,"Jumaidah aliya","jl.ketapang Indah no.56","0888651625353",false);

                Transaksi transaksi = new Tunai("TR001", customer); 

                while(true){
                    System.out.println("Pilih produk:");
                    System.out.println("1. Sepatu Olahraga");                   
                    System.out.println("2. Sandal Jepit");
                    System.out.println("3. Selesai");

                    int pilihan = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    try {
                        switch (pilihan) {
                            case 1:
                                System.out.println("Masukkan jumlah sepatu:");
                                int jumlahSepatu = scanner.nextInt();
                                transaksi.tambahProduk(sepatu1, jumlahSepatu);
                                break;
                            case 2:
                                System.out.println("Masukkan jumlah sandal:");
                                int jumlahSandal = scanner.nextInt();
                                transaksi.tambahProduk(sandal1, jumlahSandal);
                                break;
                            case 3:
                                System.out.println("Total Harga: " + transaksi.totalHarga);
                                System.out.println("Masukkan uang bayar:");
                                double uangBayar = scanner.nextDouble();
                                transaksi.bayar(uangBayar);
                                System.out.println("Transaksi selesai!");
                                return;
                            default:
                                System.out.println("Pilihan tidak valid.");
                        }
                    } catch (Exception e){
                        System.out.println("Error: "+ e.getMessage());
                    }

                }

            } else {
                System.out.println("Transaksi dibatalkan.");
            }
        }else {
            System.out.println("Login Gagal!");
        }

        scanner.close();
    }
    }
    
}
