/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KasirTokoSepatu;

import java.util.Date;

/**
 *
 * @author Hanafitria Anjani
 */
public class Member extends Customer {
    int poin;
    double diskon;
    Date tglDaftar;

    Member(String idCustomer, String namaLengkap, String alamat, String noTelepon, int poin, double diskon, Date tglDaftar) {
        super(idCustomer, namaLengkap, alamat, noTelepon);
        this.poin = poin;
        this.diskon = diskon;
        this.tglDaftar = tglDaftar;
    }

    void tambahPoin(int poin) {
        this.poin += poin;
    }
    //tukar poin method{
    
}
