/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KasirTokoSepatu;

/**
 *
 * @author Hanafitria Anjani
 */
public class Tunai extends Transaksi {
    double kembalian;

    Tunai(String idTransaksi, Customer customer) {
        super(idTransaksi, customer);
        this.metodeBayar = "Tunai";
    }

    void hitungKembalian(double uangBayar) {
        this.kembalian = uangBayar - totalHarga;
    }
    
}
