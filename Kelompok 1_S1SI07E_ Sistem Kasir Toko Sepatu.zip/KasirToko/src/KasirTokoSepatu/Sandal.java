/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KasirTokoSepatu;

/**
 *
 * @author Hanafitria Anjani
 */
public class Sandal extends Produk { 
    
    String tipeSandal;
    String bahan;
    String ukuran;

    Sandal(String idProduk, String namaProduk, double hargaSatuan, String kategori, int stok, String tipeSandal, String bahan, String ukuran) {
        super(idProduk, namaProduk, hargaSatuan, kategori, stok);
        this.tipeSandal = tipeSandal;
        this.bahan = bahan;
        this.ukuran = ukuran;
    }
}
