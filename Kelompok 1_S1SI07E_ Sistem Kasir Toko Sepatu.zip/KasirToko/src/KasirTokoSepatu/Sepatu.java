/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KasirTokoSepatu;

/**
 *
 * @author Hanafitria Anjani
 */
public class Sepatu extends Produk {
    String jenisSepatu;
    String ukuran;

    Sepatu(String idProduk, String namaProduk, double hargaSatuan, String kategori, int stok, String jenisSepatu, String ukuran) {
        super(idProduk, namaProduk, hargaSatuan, kategori, stok);
        this.jenisSepatu = jenisSepatu;
        this.ukuran = ukuran;
    } 
    
}
