/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tubes;

/**
 *
 * @author Khadeeja/Hanafitria
 */
public class Customer {
    private String id_customer;
    private String nama_lengkap;
    private String alamat;
    private String noTelepon;

    public Customer(String id_customer, String nama_lengkap, String alamat, String noTelepon) {
        this.id_customer = id_customer;
        this.nama_lengkap = nama_lengkap;
        this.alamat = alamat;
        this.noTelepon = noTelepon;
    }

    public String getId_customer() {
        return id_customer;
    }

    public String getNama_lengkap() {
        return nama_lengkap;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getNoTelepon() {
        return noTelepon;
    }

    public void transaksikan() {
        System.out.println("Melakukan transaksi...");
    }

    public void inafRwayat() {
        System.out.println("Melihat riwayat transaksi...");
    }
}
