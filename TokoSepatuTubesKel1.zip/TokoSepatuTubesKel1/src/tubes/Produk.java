/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tubes;

/**
 *
 * @author Khadeeja/Hanafitria
 */
public abstract class Produk {
    private String id_produk;
    private String nama_produk;
    private double harga_satuanProduk;
    private String kategori;
    private int stok_produk;

    public Produk(String id_produk, String nama_produk, double harga_satuanProduk, String kategori, int stok_produk) {
        this.id_produk = id_produk;
        this.nama_produk = nama_produk;
        this.harga_satuanProduk = harga_satuanProduk;
        this.kategori = kategori;
        this.stok_produk = stok_produk;
    }

    public String getId_produk() {
        return id_produk;
    }

    public String getNama_produk() {
        return nama_produk;
    }

    public double getHarga_satuanProduk() {
        return harga_satuanProduk;
    }

    public String getKategori() {
        return kategori;
    }

    public int getStok_produk() {
        return stok_produk;
    }

    public void tambahProduk() {
        System.out.println("Menambahkan produk...");
    }

    public void updateStok(int stok) {
        this.stok_produk = stok;
        System.out.println("Update stok produk...");
    }

    public void hapusProduk(String id_produk) {
        System.out.println("Menghapus produk dengan ID: " + id_produk);
    }
}
