/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tubes;

import java.util.Date;

/**
 *
 * @author ASUS
 */
public class NonTunai extends Transaksi{
    private String namaPlatform;
    private String noReferensi;

    public NonTunai(String id_transaksi, Date tgl_transaksi, double total_harga, String metode_bayar, String status_bayar, String namaPlatform, String noReferensi) {
        super(id_transaksi, tgl_transaksi, total_harga, metode_bayar, status_bayar);
        this.namaPlatform = namaPlatform;
        this.noReferensi = noReferensi;
    }

    public void bayar() {
        System.out.println("Pembayaran Non-Tunai melalui platform: " + namaPlatform);
    }
    
}
