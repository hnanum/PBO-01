/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tubes;

/**
 *
 * @author ASUS
 */
public class NonMember extends Customer{
    private boolean statusPromo;

    public NonMember(String id_customer, String nama_lengkap, String alamat, String noTelepon, boolean statusPromo) {
        super(id_customer, nama_lengkap, alamat, noTelepon);
        this.statusPromo = statusPromo;
    }

    public boolean getStatusPromo() {
        return statusPromo;
    }

    public void updateKeMembers() {
        System.out.println("Mengupdate ke status Member...");
    } 
}
