/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tubes;

import java.util.Date;

/**
 *
 * @author ASUS
 */
public class Transaksi {
    private String id_transaksi;
    private Date tgl_transaksi;
    private double total_harga;
    private String metode_bayar;
    private String status_bayar;

    public Transaksi(String id_transaksi, Date tgl_transaksi, double total_harga, String metode_bayar, String status_bayar) {
        this.id_transaksi = id_transaksi;
        this.tgl_transaksi = tgl_transaksi;
        this.total_harga = total_harga;
        this.metode_bayar = metode_bayar;
        this.status_bayar = status_bayar;
    }

    public String getId_transaksi() {
        return id_transaksi;
    }

    public Date getTgl_transaksi() {
        return tgl_transaksi;
    }

    public double getTotal_harga() {
        return total_harga;
    }

    public String getMetode_bayar() {
        return metode_bayar;
    }

    public String getStatus_bayar() {
        return status_bayar;
    }

    public void tambahTransaksi() {
        System.out.println("Menambahkan transaksi...");
    }

    public void bayar() {
        System.out.println("Pembayaran transaksi...");
    }

    public void updateStatus(String status) {
        this.status_bayar = status;
        System.out.println("Update status pembayaran...");
    }
}
