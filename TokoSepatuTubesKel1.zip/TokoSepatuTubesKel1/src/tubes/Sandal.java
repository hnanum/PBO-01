/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tubes;

/**
 *
 * @author ASUS
 */
public class Sandal extends Produk{
    private String tipe_sandal;
    private String bahan;
    private String ukuran;

    public Sandal(String id_produk, String nama_produk, double harga_satuanProduk, String kategori, int stok_produk, String tipe_sandal, String bahan, String ukuran) {
        super(id_produk, nama_produk, harga_satuanProduk, kategori, stok_produk);
        this.tipe_sandal = tipe_sandal;
        this.bahan = bahan;
        this.ukuran = ukuran;
    }

    public String getTipe_sandal() {
        return tipe_sandal;
    }

    public String getBahan() {
        return bahan;
    }

    public String getUkuran() {
        return ukuran;
    }
    
}
