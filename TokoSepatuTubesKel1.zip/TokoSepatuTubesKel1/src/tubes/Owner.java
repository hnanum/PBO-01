/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tubes;

/**
 *
 * @author Khadeeja/Hanafitria
 */
public class Owner {
    private String id_owner;
    private String nama;

    public Owner(String id_owner, String nama) {
        this.id_owner = id_owner;
        this.nama = nama;
    }
    
    public String getId_owner() {
        return id_owner;
    }

    public String getNama() {
        return nama;
    }

    public void tambahData() {
        System.out.println("Menambahkan data owner...");
    }

    public void ubahData() {
        System.out.println("Mengubah data owner...");
    }

    public void hapusData() {
        System.out.println("Menghapus data owner...");
    }

    
}
