/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tubes;

/**
 *
 * @author Khadeeja/Hanafitria
 */
public class Karyawan{
    private String id_karyawan;
    private String nama;
    private String noTelp;

    public Karyawan(String id_karyawan, String nama, String noTelp) {
        this.id_karyawan = id_karyawan;
        this.nama = nama;
        this.noTelp = noTelp;
    }
    
    public String getId_karyawan() {
        return id_karyawan;
    }

    public String getNama() {
        return nama;
    }

    public String getNoTelp() {
        return noTelp;
    }

    public void tambahData() {
        System.out.println("Menambahkan data karyawan...");
    }

    public void ubahData() {
        System.out.println("Mengubah data karyawan...");
    }

    public void hapusData() {
        System.out.println("Menghapus data karyawan...");
    }
}
