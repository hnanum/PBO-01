/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tubes;

import java.util.Date;

/**
 *
 * @author Khadeeja/Hanafitria
 */
public class Member extends Customer{
    private int poin;
    private double diskon;
    private Date tgl_Daftar;

    public Member(String id_customer, String nama_lengkap, String alamat, String noTelepon, int poin, double diskon, Date tgl_Daftar) {
        super(id_customer, nama_lengkap, alamat, noTelepon);
        this.poin = poin;
        this.diskon = diskon;
        this.tgl_Daftar = tgl_Daftar;
    }

    public int getPoin() {
        return poin;
    }

    public double getDiskon() {
        return diskon;
    }

    public Date getTgl_Daftar() {
        return tgl_Daftar;
    }

    public void tambahPoin() {
        System.out.println("Menambah poin...");
    }

    public void tukarPoin() {
        System.out.println("Menukar poin...");
    }
}
