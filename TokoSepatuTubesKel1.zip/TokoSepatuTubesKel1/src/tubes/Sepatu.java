/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tubes;

/**
 *
 * @author ASUS
 */
public class Sepatu extends Produk {
    private String jenis_sepatu;
    private String ukuran;

    public Sepatu(String id_produk, String nama_produk, double harga_satuanProduk, String kategori, int stok_produk, String jenis_sepatu, String ukuran) {
        super(id_produk, nama_produk, harga_satuanProduk, kategori, stok_produk);
        this.jenis_sepatu = jenis_sepatu;
        this.ukuran = ukuran;
    }

    public String getJenis_sepatu() {
        return jenis_sepatu;
    }

    public String getUkuran() {
        return ukuran;
    }
    
}
