/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tubes;

import java.util.Date;

/**
 *
 * @author ASUS
 */
public class Tunai extends Transaksi {
    private double jumlahBayar;
    private double kembalian;

    public Tunai(String id_transaksi, Date tgl_transaksi, double total_harga, String metode_bayar, String status_bayar, double jumlahBayar) {
        super(id_transaksi, tgl_transaksi, total_harga, metode_bayar, status_bayar);
        this.jumlahBayar = jumlahBayar;
    }

    public void bayar() {
        if (jumlahBayar < super.getTotal_harga()) {
            System.out.println("Jumlah bayar kurang dari total harga!");
        } else {
            kembalian = jumlahBayar - super.getTotal_harga();
            System.out.println("Pembayaran Tunai, Kembalian: " + kembalian);
        }
    }
    
}
